# LC Pacemaker — RULING (a): ground the value, don't tune to the window — Claude Code

**Approve (a) — raise the LC baseline, because it's a genuine fidelity correction (a real autonomous
pacemaker should not sit at the generic 0.05 default every neuromod hub carries). BUT the value must come
from the pacemaker ELECTROPHYSIOLOGY, not from the "safe window [0.10, 0.25] where DA-learning holds and the
latch stays broken." Then accept the result. This is the crux: the biology sets the value; we do NOT tune it
into the window that makes tests pass.**

## Why this method (the honesty gate)
The build correctly flagged that the LC baseline is "load-bearing for the learning gain" and picked ~0.15
"mid the safe window." **That framing — find the value where everything works — is exactly the tune-for-
result pattern we reject.** The *direction* is fidelity (LC is an autonomous pacemaker, ~1–3 Hz tonic firing;
0.05 is the ungrounded generic default and almost certainly too low). The *value* must be fidelity too:

1. **Ground the value from the electrophysiology.** What does LC's intrinsic pacemaker firing (~1–3 Hz tonic)
   correspond to as a baseline activation in the model's normalization? Set it to THAT, with the
   electrophysiological citation (Aston-Jones & Cohen; the LC-pacemaker literature) — NOT to 0.15-because-
   the-window.
2. **Then observe, do NOT tune:**
   - If the grounded value resolves the paired-learning regression AND keeps the latch broken → fidelity and
     stability coincide (as they should when the model is accurate); trustworthy *because the value came from
     the biology*; proceed.
   - If the grounded value does NOT cleanly resolve it (outside the window, re-latches, regression persists) →
     **that is a FINDING**, not a value to adjust. Surface it; the system is telling us something else is
     missing/mismodeled; go to the research. **Do NOT move LC's baseline to the convenient range.**
3. **The "safe window" analysis is DIAGNOSTIC, not prescriptive** — it tells us where the system behaves
   (useful), but it does not get to set the value. The electrophysiology sets the value.

The faithful LC is: **pacemaker tonic tone (grounded value) + phasic CRF bursts (the phasic CeA→LC we just
ruled) + α2 autoregulation (non-plastic, grounded).** No tonic-teaching artifact returns (teaching is phasic).

## Standing commitment 1 — these values are PROVISIONAL (register)
We cannot perfectly set baseline values from first principles while the system is partial — the "correct"
activation for a given firing rate depends on the whole normalized system, not yet fully assembled. So:
- **Register the LC baseline (and sweep the other neuromod hubs' generic-default baselines/setpoints — all
  0.05/0.1, never individually grounded) as PROVISIONAL values, set as faithfully as possible now, flagged
  for revisit** once the system is complete. They are "set as best we can, pending the complete-system
  retune," not "done."

## Standing commitment 2 — a future FAITHFUL self-regulation mechanism (register, literature-backed)
When the system is complete, build a spawn-time-tune-and-early-years-monitor mechanism — but as **faithful
self-regulation, with stability EMERGENT, never an optimizer reaching into the weights to force stability**
(that would be tune-for-result in a biological costume). It has a real biological referent (literature-
checked):
- **Homeostatic plasticity is the core mechanism.** Hebbian/BCM plasticity is intrinsically destabilizing;
  the brain maintains stable activity via homeostatic plasticity that provides slow negative-feedback
  adjustments to excitability/synaptic scaling — exactly our situation (BCM destabilizing → the latch →
  needing homeostatic regulation). Our R4 homeostatic scaling is a partial piece of this.
- **Developmentally staged.** The forms of homeostatic plasticity differ between juvenile and mature brain,
  recruited modularly to the circuit's developmental needs — i.e. the "tune at spawn, monitor and adjust
  through early years" shape.
- **Maturing inhibition + critical-period gating.** Inhibitory interneuron (PV) maturation lags excitatory
  development (months postnatally in humans) and gates critical periods — a real developmental
  runaway-prevention mechanism.
- **Executive maturation is a LATER contributor** — the progressively-maturing PFC provides increasing
  top-down inhibitory control (the PFC→control machinery this arc builds). (The speculative "executive tunes
  its own development" is best located here: not the initial tuner — a newborn's executive isn't online — but
  a later top-down regulator layered on homeostatic plasticity + maturing inhibition.)
- Register this as the planned mechanism with this faithful form on record, so when built, stability emerges
  from real self-regulation, tested the usual way (does stability emerge from mechanism, or is a value/
  optimizer carrying it?).

## This arc — build + verify
1. **LC baseline → its grounded pacemaker value** (from electrophysiology, cited) — NOT the window midpoint.
2. **α2 (LC→LC)** non-plastic at its grounded value; **phasic CeA→LC** (prior ruling); **B dropped +
   registered** (keystone-breaking if tonic).
3. Register: LC baseline + neuromod-default baselines as provisional; the future faithful-self-regulation
   tuning mechanism (form above).

**Verify (observe, don't tune):**
- Latch stays broken (phasic drive); α2 still not load-bearing.
- Paired-learning regression: does the GROUNDED LC value resolve `test_paired_learns_more_than_unpaired`? If
  yes → proceed (fidelity+stability coincide). **If no → STOP and surface as a finding — do NOT tune LC into
  the window.**
- Aggression keystone preserved; NA phasic; all learning tests; arena viable.
- **The global impact is authorized:** raising LC baseline lifts tonic NA broadly (LC→LA/BA/CeA/dlPFC/IML) —
  golden regen HONESTLY, behaviours may shift; this is expected and authorized (not sprung), because the
  value is grounded. Document the shift.
- Full suite green; v9 + Phase-1 intact.
- **Commit + push + STOP for reviewer clearance.** Then the two CU-shift re-examinations on the fully-clean
  mechanism.

## Process
Current architecture only; **the LC value is electrophysiology-grounded, NOT window-selected**; provisional
values + the future faithful-self-regulation mechanism registered; no result is a target (both ways — surface
a non-resolving grounded value as a finding, don't tune to green); dual-reviewed on the remote.
