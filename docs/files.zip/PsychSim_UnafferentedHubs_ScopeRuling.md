# Phasic Fix + Unafferented-Hub Finding — SCOPE RULING — Claude Code

**You were right to hold and surface — the phasic fix acted as a diagnostic and exposed a real systemic gap.
The finding must NOT be buried (the "land phasic alone, patch the test" alternative is rejected). BUT the
honest scope is NOT "afferent-complete all revealed hubs now" — that's the ballooning trap. RULING: this arc
= phasic-fix + LC-completion + CeA↔LC brake (one coupled unit, on the critical path); BF-ACh and SNc are
REGISTERED as real gaps, addressed as their own steps when their edges are on the path. This is the PVN-OT
precedent exactly.**

## The finding (reviewer-verified on the remote)
Making the teaching signal phasic exposed that some neuromodulator hubs are **structurally unafferented (zero
afferents) — they never fire**, so their gated edges' "learning" was fake (gated by a tonic baseline):
- **DA (VTA):** 8 afferents — FIRES ✅ (SNc has 0, but DA works via VTA — latent, see below)
- **OT (PVN-OT):** 3 afferents — FIRES ✅ (Part-1 fixed it)
- **CRF (PVN/BNST):** afferented — fires ✅
- **NA (LC):** **0 afferents — never fires** ❌ (gates 17 edges) ← on the critical path
- **ACh (BF-ACh):** **0 afferents — never fires** ❌ (gates 26 edges) ← DIFFERENT system, off path
- Confirmed: `LC→CeA` exists, so `CeA→LC` closes a **positive-feedback loop** (needs a brake).

## Why LC is IN this arc (and coupled to the phasic fix)
- LC completion was ALREADY the foundation step we're on (the NA teaching signal the vicarious-learning work
  needs). Not scope-creep — the foundation we were building.
- The phasic fix is **coupled to LC specifically**: the failing `test_coactive_connection_strengthens` tests
  LA→BA, which is **NA-gated** — it breaks because NA is dead. Completing LC (real NA signal) + the phasic
  gate = NA-gated edges learn honestly again. **They must land together, green.**

## Why the CeA↔LC α2-autoreceptor brake is IN this arc
`CeA→LC` + `LC→CeA` = positive feedback → saturation. The α2-adrenergic autoreceptor brake is the REAL,
grounded negative feedback on LC firing (α2 autoreceptors inhibit LC as NA rises — textbook). It's not a
saturation-patch — it's completing LC's noradrenergic mechanism **faithfully**. Part of doing LC honestly →
in scope.

## Why BF-ACh is NOT in this arc (REGISTER it — the discipline, not a dodge)
- **Different system:** the 26 ACh-gated edges target rSMG-TPJ, dmPFC, pSTS, PCun-PCC (social-cognition/
  attention network) + sensory cortices (V1, S1, S2, A1, aIns) — the **cholinergic attention/salience
  system**, NOT the control/CU critical path.
- **Off the critical path:** **none of the PFC control edges are ACh-gated** (they're NA/DA/ungated). BF-ACh
  being dead does NOT block the current work (control-disposition, CU signature).
- **Not coupled to the phasic fix:** no ACh-gated test breaks. The phasic fix lands fine w.r.t. ACh.
- **PVN-OT precedent:** when PVN-OT was found unafferented, we completed IT (the hub the work needed), as its
  own step — we did NOT sweep in all unafferented hubs. Same here: complete LC; register BF-ACh.
- **REGISTER:** "BF-ACh unafferented — the cholinergic attention/salience system never fires; 26 edges gate a
  dead signal — afferent-complete as its own grounded step (PVN-OT/LC class) when the attention/social-
  cognition work is on the critical path." (TPJ/social-cognition may well matter for a later CU study — it
  gets completed THEN, with its edges on the path. Registering = sequencing to when it's load-bearing, not
  dropping.)

## Also register (latent, not this arc)
- **SNc unafferented** — but DA WORKS via VTA (neuromod output = mean of sources; VTA firing suffices). Latent
  incompleteness, currently masked. Register: "complete when nigrostriatal DA specifically matters."

## This arc — build as ONE coupled reviewed unit
1. **Phasic teaching-signal fix** (R5 gate, `mean_activity`-referenced; general — resolves VTA-DA tonic/phasic
   too).
2. **LC afferent completion** (`CeA→LC` via CRF-R1, cited) — coupled: the phasic gate needs a real NA signal.
3. **CeA↔LC α2-autoreceptor brake** (grounded α2 autoregulation) — prevents the positive-feedback saturation,
   completes LC faithfully.

**Verify (all green together):**
- Tonic-NA artifact gone (NA rest ~0); NA fires phasically on aversive events; the α2 brake prevents
  saturation (NA doesn't run away).
- `test_coactive_connection_strengthens` passes (NA-gated LA→BA learns again — NA now fires).
- `test_substrate_learning` passes on phasic DA (load-bearing DA-preserved check).
- Full suite green; golden regen HONESTLY if behaviour shifts (understood, not tuned).
- BF-ACh + SNc registered (not fixed); the 39-quiet-edges finding documented, not buried.
- **Commit + push + STOP for reviewer clearance.**

## Then (after this clears) — the payoff on a fully-clean mechanism
Re-examine the two confounded CU shifts with phasic + live-NA: punishment-deficit **persists** → real CU
signature (major finding, re-characterize the test); **dissolves** → was the tonic artifact. Same for the
classification flip. Trustworthy answer.

## Process
Current architecture only; integrate don't bolt on; grounded/cited per edge + mechanism; **do NOT bundle
BF-ACh/SNc** (register them); no result is a target (both directions); dual-reviewed on the remote.
