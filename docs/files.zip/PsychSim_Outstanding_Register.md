# PsychSim — Outstanding Work Register (scope freeze)

**Purpose: stop functional drift.** This is the complete list of what is done, what remains, and what
is explicitly deferred. **Nothing outside this list gets built without a deliberate decision to expand
it.** If a new idea appears, it goes to "Parking lot" (§4) — it does not get built into the current
work. The intention is fixed; we finish it, we don't grow it.

Current head: `6ddb8aa` (v11) on `origin/main`.

---

## 1. DONE — built, reviewed, on origin/main (do not reopen)

- **Core organism** — substrate, four matrices (social/environmental/group/self-reflection), 1/n
  plasticity, behaviour selection. Complete and validated.
- **Legacy fully retired** — Panksepp engine gone; substrate is the sole engine (stage 5).
- **Honesty #2** — coded outcome categories removed as causal primitives (8b.4).
- **Emergent-phenomena battery** — 5/5 emerge (adolescent risk, DA/satiety, negativity bias,
  ambivalent bond, punishment-for-one=reward-for-another). Two mechanism gaps closed, no seed edit.
- **Instrument suite:** developed-agent bank · parallel-instance harness · Arena · scan controller
  (search-for-effect + search-for-match) — all built, honesty-gated structurally.
- **Seed lineage:** v9 (aggression circuit, OBS-3 closed) · v10 (physical endowment + biological sex,
  IN-CONSPEC) · v11 (4 Allen afferents, honest signs). Each byte-additive, reviewed.
- **UI console** — Phases 0–8 + accessibility. Tab shell, read-only Neural view over the live seed,
  clock/day-night, monitored-agent badges, face-only markers, pause fixed.

## 2. QUEUED — the finish line (build these, in this order, then STOP)

The intention is: **complete the CU study apparatus on complete regulatory anatomy, then run the
study.** Three items remain. Nothing else.

### 2.1 — 5-HT raphe node-pass (organism; DESIGN SPEC FIRST → review → build)
- **Why it's required, not optional:** the substrate lacks its principal aggression/impulsivity
  *regulating* neuromodulator. The CU study measures aggression regulation; measuring it without 5-HT
  is measuring a regulated system with the regulator absent. Including only the excitatory afferents
  (v11) but not the inhibitory regulator is cherry-picking-by-omission — the same error corrected in
  the v11 pass, one level up.
- **Scope:** dorsal raphe (5-HT) node + its serotonergic projections to the aggression circuitry,
  amygdala, PFC, striatum. Existence/direction only; weights SCAFFOLD; emergent effects measured, not
  designed (5-HT will mostly *dampen* impulsive aggression — that must EMERGE, never be coded
  "5-HT → less aggression").
- **Standard:** same as v9/v10/v11 — real verified citations (raphe→aggression projections + the
  5-HT/impulsivity literature), byte-additive to v11 (→ v12), one seed version, one review.
- **Discipline note:** this is a NODE not an edge pass — larger. It is the *only* organism change
  queued. After it, the organism is frozen for the study.

### 2.2 — CU-study control surface (instrument; spec exists: `PsychSim_CU_Study_Spec.md`)
- Can be built **in parallel with 2.1** — it's plumbing on the scan controller and does not depend on
  the raphe node existing.
- **Three pieces:** (a) the backtester = the scan controller applied to a CU objective (measured
  signature or held-out clinical profile, target age ~18, family/environment context); (b) validated-
  CU-seed save/load (neutral name `CU-Profile-A`, transparent/editable config, provenance-carrying,
  `candidate_hypothesis`/`corroboration:false`); (c) spawn integration (validated seeds in the dropdown,
  replacing the deprecated `fearless` presets).
- **Honesty (already specced):** objective is measured-or-held-out, never a drawn CU target; family
  variables are perturbation patterns, never coded effects; a config earns the CU name only by
  validation.
- **5-HT dependency:** a CU seed validated *before* the raphe node lands must carry
  `validated_on: pre-5HT-substrate; aggression-regulation conclusions provisional` in its provenance.
- **FIRST STEP before build:** commit `PsychSim_CU_Study_Spec.md` to origin/main (it is currently
  local-only — a sync gap) and answer the four open questions in its §9.

### 2.3 — UI redundant-artifact removal (the cleanup you asked for; §3 below is the concrete list)
- Small, bounded, no new features. Remove what the redesign superseded and the deprecated study
  interface. Do this as its own commit so it's legible.

## 3. UI redundant artifacts to remove (concrete, bounded — no new UI)

- **Deprecated temperament presets** (`fearless` / `fearless (calc.)`) and `respawn`'s `fearless_frac`
  — superseded by the CU-seed dropdown (2.2c). Remove once 2.2c exists; until then they stay marked
  DEPRECATED (don't leave a gap with no way to seed a study child).
- **The dead `neuraldesigner` sandbox route**, if still present anywhere — the live Neural view (read-
  only over the seed) replaced it. Confirm it's gone or drop it.
- **Any stale docstrings** still describing the retired Panksepp engine as current (audit
  `group_matrix.py`, `README.md`, `observer.py` prose — provenance comments recording the retirement
  stay; anything implying the engine is *live* goes).
- **Orphaned components** superseded by the tab redesign (confirm `Controls.tsx`, `MatrixEditor.tsx`,
  `NeuralEditor.tsx` are deleted, not just unimported).
- **NOT removed:** the deprecated presets stay *until* the CU dropdown replaces them (no seeding gap);
  provenance docstrings stay (they're history, not staleness).

## 4. DEFERRED / PARKING LOT — real, recorded, NOT built now (require a deliberate decision to promote)

These are legitimate but out of the current scope. They do not get built into the finish-line work.
Promoting any of them is an explicit, separate decision — not a drift.

- **Development peer-perception pathway** — who a developing agent encounters (peer-sampling model).
  Physical perception currently fires Arena-only; extending it to development needs the sampling model
  specced and reviewed (it could encode who-meets-whom). Deferred.
- **Connection-level throttling** (S4.1) — the throttle module manipulates nodes; edge-level was
  deferred. `manipulation_scope: "nodes only"` travels on scan results until/unless built.
- **PH-AGILITY / PH-SENSORY as bearer capacities** — ruled out of the social channel; may enter later
  as bearer-capacity parameters (a different mechanism). Deferred.
- **VP→LHb sign fidelity** — the single-sign-per-nucleus convention signs it inhibitory; literature
  says the LHb-projecting VP population is glutamatergic. Fix ONLY by a convention-wide upgrade to
  projection-specific signs (uniform, cited) if ever — never a per-edge override. Documented in
  `gaps_register`. Deferred.
- **Other neuromodulatory systems we may have missed** — the register is not closed; as we learn of
  systems that affect the circuitry we add them (grounded, cited, whole-system, not the subset that
  suits a hypothesis). None currently identified beyond 5-HT (2.1). Deferred by definition until
  identified.
- **Real held-out field-data patterns** — for search-for-match / the CU study's clinical-profile
  objective. Researcher-supplied, properly sourced, `not_used_in_calibration`. Not synthetic. Pending.

## 5. The rule that keeps this from drifting

1. **The finish line is §2 (three items) → then run the study.** That is the whole remaining
   intention.
2. **New ideas go to §4 (parking lot), not into §2.** Promotion is a deliberate, separate decision.
3. **Organism changes are frozen after 2.1** (the raphe node). No further seed versions before the
   study without an explicit re-opening.
4. **Every change is byte-additive, cited, reviewed, and confirmed on origin/main** — the discipline
   that held eleven seed versions.
5. **When §2 is done and the study is run, the build is complete.** Resist "one more system" unless it
   is genuinely identified as missing (§4) and promoted deliberately.
