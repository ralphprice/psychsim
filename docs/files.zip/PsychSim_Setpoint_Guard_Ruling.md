# Setpoint Guard Tension — RULING — Claude Code

**Your mechanism correction is accepted and important. The guard re-expression is APPROVED in principle — the
spec is explicit and uniformity was pinning current state — but do NOT weaken it to a range check. It must
retain its real protective value: no *ungrounded* per-circuit setpoints. Details below.**

---

## 1. Your mechanism correction — accepted, and it makes the finding MORE serious

My diagnosis said `mean_activity[LC]` settles >= 0.15 at rest. You corrected it: the alpha2 autoreceptor pulls
LC below its baseline, so at pure rest it settles to 0.10 and **homeo is neutral** — no rest-driven erosion.
The erosion is **event-driven**: LC fires -> `mean_activity` rises above the 0.1 setpoint -> `CeA->LC` erodes
-7.4%/60k, while setpoint 0.15 holds it at +0.0%. Direction and fix correct; mechanism wrong. Recorded.

**But note what event-driven erosion actually means, because it is worse than the rest-driven version I
described:**

> **The more aversive events an agent experiences, the more its aversive-learning pathway erodes.**

Experience of threat would have progressively destroyed the capacity to learn from threat — in proportion to
how much threat was experienced. Over a life-course, a **harsh-reared** agent would end up with a
systematically weaker NA teaching signal than a **warm-reared** one, purely as an artifact of the setpoint
mismatch. **Warm-vs-harsh rearing is the core developmental manipulation** — this would have silently biased
exactly the comparison the studies rest on, in a plausible-looking direction. Document this as the reason the
fix matters; it is not housekeeping.

## 2. The guard — APPROVED to re-express, but NOT as proposed

Your reading is right and I accept it: **§S2.5 says "per-circuit `homeostatic_setpoint` … the target mean
activity of a nucleus"** — per-circuit **by design**. The uniformity assertion held only because every circuit
carried the ungrounded default. It was **pinning current state while wearing a design guard's name.** And
uniformity cannot be a design principle: different nuclei have materially different intrinsic firing-rate
targets (LC pacemakers ~1-3 Hz tonic; DA neurons burst; cortical pyramidals average far lower). A uniform
setpoint across 83 circuits is a **placeholder** — and it just demonstrably produced an artifact.

**But the proposed replacement (separation + "in (0,1]") is too weak.** Whatever its author intended, the old
guard had a real protective property: **it would catch any per-circuit setpoint change.** That is an
anti-tuning property worth keeping — "adjust a per-circuit setpoint until it works" is precisely the move we
forbid. A range check would not catch it.

**Re-express the guard to assert BOTH:**
- **(a) the substantive S2.5 separation** — setpoints are per-circuit firing-rate targets; body-variable
  set-points are a distinct scaffold quantity not read from the seed. (As you proposed — this is the real
  spec point, and the sibling separation test confirms it holds.)
- **(b) every setpoint deviating from the scaffold default is explicitly GROUNDED and CITED** — currently
  exactly one (LC, cited to the pacemaker electrophysiology, paired with its baseline). **A new ungrounded
  deviation must FAIL.**

That permits grounded fidelity corrections and still blocks tuning. **Document as a finding, not a silent
re-baseline** — as you proposed.

## 3. The sibling `next(iter(...))` — yes, fix it
An unambiguous non-determinism bug, now exposed by having two distinct setpoints. Arbitrary-pick over a set
was always wrong; it only looked fine while the set was a singleton. Fix it.

## 4. ESCALATE the provisional register entry — this is a known systematic bias, not cleanup

The 0.1 setpoint is **ungrounded across 82 circuits**, and LC has now demonstrated the default can be
materially wrong in a way that compounds. Generalise the entry:

> **Any circuit whose true homeostatic firing-rate target exceeds the 0.1 default is being persistently
> over-suppressed — its afferents eroded in proportion to how active it is.** We do not currently know which
> circuits those are. Uniform-0.1 is a scaffold, not a grounding; the paired `baseline`/`setpoint` values
> describe one quantity (a circuit's intrinsic target rate) and must be grounded together, per-circuit.

**Audit home: the future faithful self-regulation mechanism.** That mechanism is the natural place for this —
it is precisely the thing that should be setting/regulating firing-rate targets from real homeostatic
dynamics rather than from a global placeholder. Link the two register entries.

## 5. Land
- LC setpoint 0.15 paired with the grounded baseline, same citation. Verified: `homeo_factor` ~ 1.0 at rest,
  `CeA->LC` stable under events, NA phasic (rest 0.050 / aversive 0.207), golden unshifted.
- Guard re-expressed per §2 **(a)+(b)**; sibling non-determinism fixed; both documented as findings.
- Register: R4 has no plasticity guard ("non-plastic" requires bounds-pinning; open question whether R4 should
  skip `plasticity_schedule=None`); provisional baselines **and paired setpoints**, escalated per §4 and linked
  to the self-regulation mechanism; the event-driven erosion + its warm-vs-harsh bias implication.
- Full suite green; **commit + push + STOP for reviewer clearance.**

## Process
A committed test that pins current state is not a design guard — but re-expressing one must preserve what it
actually protected, not just what it literally asserted. Grounded deviations pass; ungrounded ones fail.
