# Phase A — the keystone flip: RULING

**Hold the commit was right. Reporting not tuning was right. And your lean on Q1 was right — it is the real
question, and the literature answers it completely.**

---

## 0. First, what you found, stated precisely — because this matters more than the flip

**The v9 neutral floor was passing for the wrong reason.** It held because `CeA→PAG(−,0.70)` tonically
suppressed a lumped node — and CeA's own citation (Tovote) puts it on the **freezing** column. **CeA does not
project to dPAG at all.** So the model was restraining attack with a projection that, in the real anatomy,
restrains nothing of the sort.

**Be precise about what this does and does not mean:**
- ❌ It does **not** mean aggression was coded. The `HYPdm` half stands, untouched, at 0.000.
- ✅ It means **the check that would have caught it was not checking.** The floor certified an *outcome*
  produced by an *artifact*.

**And this is the sobering part, because §15.1 of the master says of the neutral floor: *"That last check is
the load-bearing one… The floor holding is how the substrate proves it did not smuggle the answer in. This is
the pattern every later keystone copies."*** The pattern every later keystone copies **was itself resting on
a lumped node.** The floor's *logic* is still right. Its *mechanism*, in this one case, was luck.

> **NEW PRINCIPLE — record it: a passing keystone certifies the OUTCOME, not the mechanism that produced it.
> An artifact can hold a keystone, and then the keystone certifies nothing. Always ask what is holding it.**

**Your line — *"I won't answer it by re-pointing CeA→dPAG — that would be inventing anatomy to restore a
result"* — is the whole discipline in one sentence.** That is exactly the move that was available and exactly
why it was forbidden. Noted and affirmed.

---

## Q1 — MISSING INHIBITORY ELEMENT. Not a test re-expression. And it is grounded.

**Principle 1: instability = a missing pathway, not a wrong weight.** An unsuppressed dPAG at rest is an
instability. Your lean is correct: **the floor was held by an artifact, so "what actually restrains dPAG at
rest?" has never been asked.** It has an answer, and it is well-established.

### The missing element: `dPAG-GABA` — a tonically-active local inhibitory population
**Stempel & Evans et al., *Current Biology* 2024 — "Tonically active GABAergic neurons in the dorsal
periaqueductal gray control instinctive escape in mice":**
- **VGAT⁺ dPAG neurons fire action potentials tonically *in the absence of synaptic input*** — autonomously.
- They are **the major source of inhibition to the VGluT2⁺ (glutamatergic, output) dPAG neurons**.
- **Their activity sets the threshold for escape initiation**; it transiently *decreases* at escape onset and
  increases during escape, peaking at termination.
- Supporting, older: **local GABA_A antagonist in PAG makes a previously sub-threshold stimulus
  suprathreshold** — the inhibitory tone is what holds the floor.
- **GABAergic neurons in the lateral and ventral PAG have higher baseline firing rates than the excitatory
  neurons.**

**So: `dPAG` is restrained at rest by a tonically-firing local GABAergic population, and that population IS
the escape threshold.** It was never CeA. The model reproduced the right floor from the wrong mechanism
because the lumping let CeA do that job.

### ★ This is the LC pattern again — so the LC rules apply exactly
A tonically-firing autonomous population whose rate is a **grounded electrophysiological fact**, setting a
threshold. Therefore:
- **Set `dPAG-GABA`'s baseline from the electrophysiology, NOT from what restores the floor.** The grounded
  facts are relational and usable: it fires **tonically without synaptic input**, and its **baseline rate is
  higher than the excitatory population's**.
- **Pair the setpoint to the baseline** (principle 10). They are one quantity.
- **If the grounded rate does not restore the floor, that is a FINDING, not a tune.** This is the LC
  pacemaker ruling, verbatim. **The temptation to pick the baseline that makes the floor green is the exact
  fudge this whole arc exists to refuse.**

### ★ And it independently validates what you just built
The same source: **"Disinhibition of the PAG has been suggested as a mechanism for initiating other
instinctive behaviours, such as *vocalisations and freezing*, with inhibitory long-range projections from
forebrain regions inhibiting local GABAergic circuits within the PAG."**

That is **`CeA → vlPAG-GABA` exactly** — arrived at independently, from a different literature, and stated as
the general architecture. **One architecture, every column: a tonically-active local GABA gate, disinhibited
by long-range forebrain inhibitory projections.** Your Phase A build is the special case; this is the rule.

**Register for Phase B:** the same sentence names **vocalisation** as disinhibition-initiated — so
**`PAG-PANIC` very likely needs its own gate too.** Do not build it now; it belongs with the vocal limb.

### 🎁 Bonus — this resolves the DRN receptor flag (the third target-cell resolution this phase)
The flag said *"PAG 5-HT 1A/2A mixed"* — because the two receptors have **opposite molecular effects** (5-HT1A
Gi hyperpolarises; 5-HT2A Gq excites) yet **both inhibit escape**. The resolution is the target cell, not the
receptor: **5-HT2A agonists inhibit escape *by activating the GABAergic interneurons located in the dPAG*** —
and bicuculline blocks that anti-escape effect, proving the route. So:
- **`DRN → dPAG-GABA` on 5-HT2A (Gq, +)** → excites the gate → **net inhibition of escape.**
- **`DRN → dPAG` on 5-HT1A (Gi, −)** → direct hyperpolarisation → **also inhibition of escape.**

**Two receptors, opposite signs, same behavioural outcome — because they land on different cells.** That is
§3.7's convention vindicated about as cleanly as it could be. **Build both; retire the flag; cite it.**

---

## Q2 — the provocation flip: the SAME finding. Do not characterise it yet.

`restrain → aggress` on adult provocation is **not a second result.** It has one cause with the floor flip:
**dPAG lost an inhibitory input it should never have had, and nothing real has replaced it.** The adult PFC
brake's *sufficiency* was resting on the same artifact — it was never carrying the load alone.

**Principle 6 extends, and record the extension: no grounded values into a partial assembly — and no
BEHAVIOURAL CHARACTERISATION from one either.** The system is expected to misbehave until the real components
are present. Characterising a flip produced by a known-incomplete assembly would be inventing a finding out of
a gap.

**So: neither re-prove nor re-characterise. Build `dPAG-GABA` at its grounded rate, then re-run all three.**
If a flip **persists** after the real mechanism is in at its grounded value — **that is a finding, and a real
one.** Report it then.

---

## Q3 — count pins: re-baseline, but name the delta

Mechanical, yes — **but a bare `assertEqual(len(circuits), 87)` is a number, not a guard.** Per principle 11,
what the pin protects is *no silent structural change*. Re-baseline to **87** with the delta **named in the
test**: `−PAG · +vlPAG · +dPAG · +vlPAG-GABA · +NuAmb-vocal · +NuFac` (NuAmb→NuAmb-cardiac is a rename; no
count change). **Expect 88 when `dPAG-GABA` lands** — re-baseline again, naming it. A pin that records why is
a guard; a pin that records a number is a speed bump.

---

## The domain bug — excellent catch, and it generalises further than you flagged

**A low-THREAT temperament would have throttled the facial motor nucleus.** That is a construct-validity bug
of **exactly the AFFECTIVE_EMPATHY class — the second one caught in this arc, both before they became
findings.** *"Low-threat agents show less facial expression"* would have been **true by construction.**

**The generalisation, and it is a standing hazard: the domain IS a throttle surface.** So **domain assignment
is a construct-validity decision, not a taxonomy decision** — every circuit's domain silently defines what a
temperament dial reaches. **This joins the throttle-set audit as the same class of check.**

And your flag is right: **branchiomotor nuclei have no honest home in seven domains.** `NuFac`, `NuAmb-vocal`
and the Phase-D cortical motor nodes need an **eighth domain — motor/effector — and it must not be reachable
by a temperament dial.** **Register it as a Phase D prerequisite; do not build it now.** The immediate fix
(don't inherit `defensive_threat`) is correct — carry it.

---

## The A+B falsification — register the narrowing; it does not re-open

The falsification ran through both `CeA→PAG` and `CeA→HYPdm`. **The HYPdm half survives; the PAG half
dissolves — so the conclusion (B breaks the keystone) stands, on a narrower basis than recorded.**
**But note it was measured against a floor we now know was artifact-held**, so the *test* should be re-run
once the floor is restored honestly. **Register both. Do not re-open B now** — it is not on this path.

---

## Build
`dPAG-GABA` (grounded rate, paired setpoint) · re-route the dPAG glutamatergic output through it ·
`DRN → dPAG-GABA` (5-HT2A) and `DRN → dPAG` (5-HT1A), flag retired · count pins re-baselined with the delta
named · domain fix carried. **Then re-run the floor, plain-threat, and adult provocation, and report what
holds and what does not — at the grounded rate, whatever it gives.**

**Disclosed and carried to the audit:** Hao's feeding context; "anterior vlPAG" as an un-modelled sub-grain;
`SC-Pv → dPAG` at 0.50 against a literature that calls that synapse weak (the Point-1 candidate — still its
own pass, still not now).
