# LC α2 Latch — RULING: A + B (both grounded) — Claude Code

**Excellent catch — surfacing the load-bearing α2 value rather than committing the green-but-value-carrying
A-alone is exactly right. RULING: A + B together, both grounded. The load-bearing α2 value is the TELL that a
mechanism is missing (the CeA self-brake, candidate B) — and we've now TRACED it, so we add the mechanism,
not carry it in the value. That's the whole project's lesson: when a value is load-bearing for stability, the
arbitrariness is in a mechanism the value compensates for; trace it, add it, don't tune.**

## Both halves verified on the remote
- **Candidate B is real:** CeA has `CeA-GABA→CeA` (GABAergic self-inhibition circuit) but it is driven **only
  by PVN-OT** (`PVN-OT→CeA-GABA`), **NOT by CeA's own activity.** So there is NO activity-driven CeA
  self-brake — the intra-amygdala feedback inhibition (CeAl→CeAm, ~95%-GABAergic habituation) that makes CeA
  habituate to sustained threat in reality is ABSENT. HEAD's CeA recovers only via weak passive decay, which
  the loop overpowers.
- **The α2 value IS load-bearing:** `LC→CeA` is `moderate`/`anatomy` (band, not grounded magnitude); with A
  alone, α2 must be pushed to ~0.85 to keep loop-gain<1 — i.e. the value is partly substituting for the
  absent CeA self-brake. Correctly identified.

## Why A + B (not A-alone, not A-now-register-B)
The latch exists because we added the excitatory loop arm (`CeA→LC`) while **both** natural brakes were
missing/absent: α2 (not yet added) AND CeA self-inhibition (absent). In reality a CeA↔LC positive loop does
NOT latch — because **both** brakes operate: α2 limits LC, CeA self-inhibition limits CeA. Making ONE brake
(α2) do BOTH jobs is exactly why its value has to be pushed strong. **The load-bearing α2 value is the
signature of the missing CeA brake.**

- **Not A-alone:** would knowingly commit an α2 value that's partly tuned-to-loop-gain, compensating for a
  mechanism we've ALREADY traced as missing and grounded. That's the value-masks-a-mechanism pattern we
  refuse every time.
- **Not A-now-register-B:** register-and-defer is for gaps that aren't currently biting (BF-ACh, SNc — off
  path, distorting nothing). B is biting RIGHT NOW — its absence is *why* A's value is a tripwire, in the arc
  we're committing. It's part of making THIS fix honest, not a future refinement.

## The build — A + B, both grounded
1. **α2 autoreceptor (A):** `LC→LC`, **NON-PLASTIC** (category correction — autoreceptors are structural, not
   learned associations), at its **GROUNDED** strength — cited α2 autoinhibition pharmacology (the dominant
   intrinsic LC brake: clonidine silences LC, yohimbine disinhibits it). The value comes from the
   pharmacology, **NOT** from what stabilizes the loop.
2. **CeA activity-driven self-inhibition (B):** add the cited intra-amygdala GABAergic feedback — make
   `CeA-GABA` **activity-driven by CeA** (add `CeA→CeA-GABA` so CeA's own activity drives its self-inhibition,
   not only PVN-OT), grounded in the ~95%-GABAergic CeA feedback-inhibition/habituation literature
   (CeAl→CeAm). This is the ABSENT habituation brake. Cited, at its grounded band.

## The LOAD-BEARING honesty verification (this is the "no result is a target" resolution)
**Confirm the loop is stable with BOTH brakes at their GROUNDED strengths — α2 at its pharmacological value,
NOT a value chosen to stabilize the loop.**
- **If stable at grounded values** → the real mechanisms carry it (as they do in reality); the α2 value is no
  longer load-bearing (it's grounded, and the loop is stable *because both real brakes operate*). The viable
  arena is now TRUSTWORTHY — it emerges from faithful mechanism, not a tuned value. Proceed.
- **If the loop STILL needs α2 beyond its grounded strength even WITH the CeA brake present** → something is
  still missing. **Surface it, trace further — do NOT tune α2 to close the gap.**

**The "wanted look" (arena viable) is trustworthy WHEN it emerges from grounded mechanism, suspect WHEN it
depends on a load-bearing value. A+B moves it from suspect to trustworthy. That's why you don't accept the
viable arena under A-alone, and can under A+B-at-grounded-values.**

## Verify + land
- Both brakes cited, grounded, at grounded strengths; α2 non-plastic (pinned, holds through threat episodes);
  CeA self-inhibition activity-driven.
- Latch broken (CeA recovers ≈ HEAD through neutral episodes); arena viable (K ≈ HEAD) — **emergent from the
  two brakes at grounded values**, verified α2 not load-bearing.
- NA still fires phasically; `test_coactive_connection_strengthens` + `test_substrate_learning` green.
- Full suite green (golden regen HONESTLY); v9 + Phase-1 intact.
- **Commit + push + STOP for reviewer clearance.** Then — and only then — the two CU-shift re-examinations on
  the fully-clean mechanism.

## Process
Current architecture only; integrate don't bolt on; grounded/cited per element; **the α2 value must be
pharmacological, not loop-stabilizing** — the CeA brake carries what the value was masking; no result is a
target (both directions — surface the viable arena's dependence, don't accept it until it's grounded-mechanism-
emergent); dual-reviewed on the remote.
