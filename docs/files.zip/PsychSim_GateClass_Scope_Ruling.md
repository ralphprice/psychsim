# Phase B step 0 — CLEARED (`003768e`) + the gate-class scope ruling

**Verified against `origin/main`:** `motor_effector` present with `NuAmb-vocal`/`NuFac`; absent from
`_THROTTLEABLE_DOMAINS` **with the exclusion and its reasoning stated in-file** (scan.py:41) so a later edit
must argue with it; `NuAmb-cardiac` correctly left autonomic; `structural_element` genuinely **derived**
(`c.domain in _THROTTLEABLE_DOMAINS and not c.structural_element`) rather than a curated id list; `dPAG-GABA`
pinned and measured at 0.00 against CeA 0.60; guard re-expressed to what it protects; 537/0.

**Finding the `seed_substrate` surface was the material catch.** I named the scan; **you found the one that
throttles by domain on every agent.** My ruling would have pinned the lesser surface and left the live one.

---

## 1. Your distinction is right — and it makes my ruling too broad. Reversing part of it.

> *"the temperament throttle is a **reactivity dial** (perverse on any gate), whereas the scan is a **lesion
> search** (lesioning an interneuron is a legitimate experiment). Those may not warrant the same exclusion."*

**Correct, and I conflated them.** I wrote *"it must not be throttled"* against a single word — "throttleable"
— that turned out to name two different things. They are not the same act:

- **The temperament throttle is a MODEL CLAIM** — an assertion about what varies between individuals.
- **The scan is an EXPERIMENT** — an assertion about nothing; a question.

**So:**

### 1a. TEMPERAMENT — exclude the whole gate class. ✅ Extend.
The perversity is a property of **being a gate**, not of having a grounded rate. `dPAG-GABA` was the
strongest *case*, not the boundary of the *argument*. The α2 reasoning carries verbatim: **a structural
element is not a reactivity dial, any more than it is a learned association.** You measured it live on five;
mark the class in the seed — **per-circuit, with a reason each** (data, like `dominant_receptor`), so the
query stays derived and nothing becomes a list.

### 1b. SCAN — RELAX `dPAG-GABA`'s exclusion. ❌ My over-reach; undo it.
**Lesioning an interneuron is exactly the experiment that PROVED this gate sets the threshold** — Stempel &
Evans silenced VGAT⁺ dPAG optogenetically, and **you ran the same experiment yourself** (silence the gate →
dPAG leaks 0.0000 → 0.0202). **Forbidding in the scan the very manipulation we used as proof is incoherent.**
And with *"every column has a gate"* as the architecture, excluding gates would blind the scan to an entire
class of phenotypes — including, quite possibly, the ones we are looking for.

**`structural_element` should mean: not a learned association (plasticity), not a reactivity dial
(temperament) — but still lesionable (scan).** Three surfaces, and the property speaks to two.

---

## 2. ⚠️ The survey found a sixth, and it is the consequential one: **`ITC`**

Full gate-class sweep against the remote — still temperament-throttled, `structural_element` unset:

| gate | domain | consequence when the dial goes down |
|---|---|---|
| **`ITC`** | defensive_threat | **← you missed this one** |
| `CeA-GABA` | defensive_threat | disinhibited CeA → more fear output |
| `vlPAG-GABA` | defensive_threat | disinhibited freezing column |
| `DRN-GABA` | defensive_threat | disinhibited 5-HT node |
| `vmPFC-GABA` | defensive_threat | disinhibited vmPFC |
| `dlPFC-GABA` | executive | disinhibited dlPFC |

*(`SC-Pv` matched my pattern spuriously — it is a sensory relay, not a gate. Not in scope.)*

**`ITC` matters more than the other five combined.** It is the GABAergic **fear-extinction gate**, and it is
**the cell the entire prefrontal control route runs through** — `vmPFC → ITC` and the `vlPFC → ITC` re-target
we landed in the memory arc exist precisely because glutamatergic PFC cannot inhibit LA directly. So a
throttled `ITC` means **a low-threat temperament gets a disinhibited amygdala AND a disabled extinction gate
— i.e. impaired prefrontal control over fear, by construction.** *"Low-threat agents show impaired
extinction"* is exactly the kind of finding the CU study would report, and it would be an artifact of the
dial. **Add it to the class.**

---

## 3. ★ The deeper finding — register it; do not act on it. It is bigger than the gates.

**Why is the dial perverse on gates at all?** Because **temperament has two components and this model fuses
them.** Rothbart's construct is **reactivity** *and* **self-regulation** — and in the substrate, **the driven
circuits are the reactivity and the gates ARE the regulation.** A domain-uniform scale hits both, so
*"low threat"* comes out as *"less reactive **and** less regulated"* — which is not what it names, and not
what temperament is.

**And this is thesis-critical, not housekeeping.** Effortful control is a temperament construct in the CU
literature. More to the point: **sophrosyne — self-command — is regulation, and psychopathic disposition is
reactivity. A high-functioning, adaptively expressed disposition IS a reactivity/regulation dissociation:
low reactivity, HIGH self-command.** The current dial **cannot express that phenotype at all**, because one
knob moves both. **The thesis's central construct is a dissociation the temperament model fuses by
construction.**

**Register for its own pass — it needs reactivity and regulation as separate surfaces.** It is not on the
expression path and must not balloon this level. But it belongs in the return-path register **above** the CU
study, and the expression work touches it from the other side: **the volitional suppressor is a regulation
element too.**

---

## 4. Then Phase B — the vocal limb
`PAG-PANIC → NuAmb-vocal` · the `vlPAG → NuAmb-vocal` grounding question · `PAG-PANIC`'s own gate (same
architecture — the source names vocalisation as disinhibition-initiated) · the emotional route to the face ·
the respiratory limb · `SympOut`'s efferent.

**Carried, not acted on:** `dPAG-GABA`'s missing release (the escape circuit is incomplete; escape/flight
claims provisional until its forebrain source is grounded in its own pass) · the reactivity/regulation
finding above · `SC-Pv → dPAG` 0.50 as a Point-1 candidate · the A+B narrowing and its artifact-held floor.
