# LC Foundation — the tonic-NA artifact + the two shifts — RULING — Claude Code

**You were exactly right to hold. RULING: the tonic-NA elevation is a MECHANISM ARTIFACT, not correct
emergence — so do NOT commit the foundation as-is, and do NOT accept the two study-relevant shifts, because
they are confounded by the artifact. Resolve the tonic/phasic teaching-signal mechanism FIRST, THEN
re-examine whether the CU signature is real. Do not tune `CeA→LC`; do not regen golden; do not
re-characterize the punishment test yet.**

## Why the tonic-NA is an artifact (reviewer-verified on the remote)

The teaching-signal architecture is **phasic** — the substrate "measures drives PHASICALLY (activation above
baseline)" (social.py). DA works because VTA is driven *above* baseline by a reward event and returns.
`CeA→LC` breaks this: CeA sits **tonically elevated at rest** (its own afferents hold it up), so `CeA→LC`
transmits that tonic level into LC continuously → **resting NA 0.05→0.22** (vs DA resting ~0.05). The NA
teaching signal loses its phasic character — the NA-gated edges over-consolidate *all the time*, not just on
the aversive event, broadly biasing development toward the NA-gated (defensive/control) circuits. **This is
the same tonic-vs-phasic problem deferred for VTA reward-gating** ("tonic-DA flattens phasic RPE"). A teaching
signal MUST be phasic (a deviation from baseline = "something bad happened NOW"); CeA's tonic activity making
it tonic is a wiring consequence, not a faithful noradrenergic teaching signal.

## Why the two shifts must NOT be accepted yet (the honesty crux)

Both shifts appeared *simultaneously with* the tonic artifact, so they are **confounded** — we cannot tell if
they are real emergence or artifacts of the tonic over-consolidation:

1. **The flipped CU punishment-deficit** (spread 0.053→0.133; throttle 0.0→1.0: punishment 0.173→0.039). This
   LOOKS like the CU signature (throttling affective empathy starves the NA signal → punishment
   insensitivity). **That is exactly why we must be most skeptical of it** — a result that looks like the
   finding we most want is the one to distrust until the mechanism producing it is clean. It might be the
   real CU signature, or an artifact of tonic NA distorting all development. **Indistinguishable right now.**
2. **The classification flip** (`shared_root|warm_firm` → `defensive_threat`-dominant): a warm-reared agent
   developing defensively — consistent with tonic-NA broadly biasing development toward the NA-gated
   defensive/control circuits. Likely (at least partly) the artifact.

**No result is a target — and that cuts BOTH ways: we don't tune toward a wanted result, and we don't ACCEPT
a wanted-looking result a mechanism artifact might have produced.** Accepting the CU finding now (re-
characterizing the test) would bake an artifact-confounded result into the model as if it were the signature.
You were right not to.

## The ruling — resolve the mechanism first, then look

1. **HOLD the foundation step — do not commit.** Its goal (NA fires under aversive) is achieved, but it
   carries the tonic artifact, so it's not clean.

2. **Resolve the tonic/phasic teaching-signal mechanism** — make the neuromodulator TEACHING signal **phasic**
   (the source's activation *above its baseline*), so a tonically-elevated source (CeA) does NOT produce a
   tonic teaching signal. This is grounded (phasic DA/NA teaching signals ARE deviations from tonic baseline)
   and should be solved **generally for the teaching-signal architecture** — which resolves the deferred
   VTA-DA tonic/phasic case in the same stroke. **Do NOT fix this by tuning the `CeA→LC` weight** (that's the
   tune-the-value-to-mask-the-symptom trap). It's a mechanism fix, not a value fix. Bring the mechanism
   approach for review before building it (it touches the teaching-signal path — a real change).

3. **ONLY AFTER the teaching signal is phasic, re-examine both shifts:**
   - If the punishment deficit **persists** when affective empathy is throttled (now because the *phasic* NA
     signal is genuinely starved, not tonic distortion) → it's the **real CU signature**, a major finding, and
     THEN the punishment test is re-characterized honestly.
   - If it **dissolves** → it was the artifact; the original "weak, not a failure" characterization stands.
   - Same for the classification flip: re-check whether it persists with phasic NA.

**Cleaning the mechanism can only strengthen a real finding (removing the confound) or dissolve a false one —
either way we get a trustworthy answer instead of a seductive confounded one.** If the CU signature is real,
phasic NA won't destroy it.

## Process
- Do NOT commit, regen golden, re-characterize the punishment test, or tune any weight until the teaching
  signal is phasic AND the shifts re-examined.
- The tonic/phasic mechanism fix is the next reviewed step — bring the approach for review before building
  (it's a teaching-signal-architecture change, general, resolving VTA-DA too; not a CeA→LC tune).
- Current architecture only; integrate don't bolt on; no result is a target (both directions); dual-reviewed
  on the remote.
