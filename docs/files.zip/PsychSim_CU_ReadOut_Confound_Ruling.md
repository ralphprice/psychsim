# Full-Suite Gate — CU Read-Out Confound — RULING — Claude Code

**You were right to hold and not regenerate the CU crux. RULING: the punishment read-out is confounded BY
CONSTRUCTION — this is now verified structurally, not inferred. Fix the read-out on measurement principle,
validate it, THEN read whatever the CU answer is. Hold LC 0.15 (grounded). Do NOT re-baseline
acting-readiness until it's diagnosed. Register the general finding — it's the big one.**

---

## 1. The punishment read-out is confounded BY CONSTRUCTION (reviewer-verified on the remote)

`punishment_learning` sums **DEFENSIVE_OUTPUT = (CeA, PAG, BA)**.
**LC efferents = [LA, BA, CeA, dlPFC, IML].**

**==> LC projects DIRECTLY into 2 of the 3 circuits the read-out sums (CeA, BA).**

So the metric **includes LC's own tonic output inside its "defensive output" signal.** It **cannot be
tonic-NA-invariant by construction.** It was only ever valid **while LC was structurally dead** (unafferented
→ NA flat at 0.05). Giving LC its correct afferents and pacemaker — i.e. making the model *right* — exposes
that the measurement was never separating tonic defensive tone from learned cue-specific aversion.

Your mechanistic pin confirms it independently: **`after` = 0.362 > HEAD's `after` = 0.328** — the aversion
IS learned, *more strongly than HEAD*. The difference only goes negative because the tonic-NA-inflated
`before` (0.341→0.456) drifts downward across the 60 trials as the phasic CeA→LC adapts. That is a
**drifting-baseline confound** — a measurement-design problem, not a learning failure.

## 2. Fix the read-out — but ON PRINCIPLE, then read the answer (the honesty gate)

**Specify and justify the corrected read-out BEFORE looking at what it says about CU.** It must isolate
*cue-specific learned change* from *tonic tone*.

- **Preferred: a contrast design measured at the same timepoint** — conditioned cue vs. control/unpaired cue.
  Tonic tone is common to both and **cancels in the contrast**. This is the scientifically standard control
  for exactly this confound, and it is already the design of `test_paired_learns_more_than_unpaired`.
- **Also defensible: read the learned weight change directly** (the cue→CeA/BA plasticity — the engram is
  ground truth for "did it learn"). Consider reporting both: learning (weights) and behavioural expression
  (contrast), since the CU claim spans both.
- **MANDATORY validation — the proof it isn't just a nicer metric:** the corrected read-out must give ~0 when
  nothing is learned, **regardless of NA tone** (tone-invariance check). Demonstrate that.

**THEN read the CU answer off it — whatever it says, either direction.** Do NOT select the read-out that
produces (or erases) the CU signature. Specify → validate → read.

## 3. This IS the scheduled re-examination — and the finding is bigger than persists/dissolves

Document it as the substantive result: **the punishment read-out was only valid while NA was structurally
dead.** With a live, correct NA it conflates tonic defensive tone with learned aversion — so the old metric
*could not answer* "is the CU signature real?" at all.

Note also (as a question for the analysis, not an assertion): the **original tonic-NA CU scare was measured
with this same read-out**, so it was plausibly **doubly confounded** — teaching signal *and* measurement. The
phasic teaching fix cleaned the gate; it did not make the read-out NA-robust. Whether the read-out confound
explains that result's specific shape is for the corrected analysis to determine.

## 4. Hold LC = 0.15 — no reconsideration

Agreed, and your reasoning is exactly the method: the value is **electrophysiology-grounded**, and per the
ruling a grounded value whose consequences break something is a **finding, not a tune**. **Do not window-fit
it.** The consequences are the finding; we fix what's actually broken (the read-out), not the grounded value.

## 5. Acting-readiness — DIAGNOSE before re-baselining (do not accept "marginal" as emergent)

teen 35→39 vs child 37→38 flips a committed v9 keystone on a **1-step margin**. "Marginal" is not a reason to
accept it — it's a reason to find out which of three things it is:

- **(a) Read-out confound (same class as punishment)** — is "steps-to-approach" itself tone-sensitive? Tonic
  NA = arousal/vigilance, which plausibly shifts approach latency for reasons unrelated to the dual-systems
  developmental phenomenon. If so → fix the read-out on the same principle.
- **(b) A real, robust behavioural consequence of correct NA** — check across seeds. If robust → it's a
  genuine finding about how tonic NA affects the dual-systems balance; the keystone gets **honest
  re-characterization with the mechanism understood**, not a silent regen.
- **(c) Resolution noise on a thin margin** — the keystone was asserted on a 2-step margin (35 vs 37) and is
  now measured in discrete steps at 39 vs 38. If it's noise, **the finding is that the keystone's margin is
  too thin to be a reliable assertion** — itself worth knowing.

**Do not silently re-baseline a committed keystone on a 1-step flip.** Diagnose, surface, then decide.

## 6. REGISTER the general finding — this is the important one

**Several behavioural read-outs were established and validated while NA was structurally dead (LC
unafferented → NA flat 0.05). With a live, correct NA they may not be NA-robust — they may conflate tonic NA
tone with the thing they claim to measure.**

- **Punishment: a pinned instance** (sums circuits LC directly drives — confounded by construction).
- **Acting-readiness: a candidate** (diagnose per §5).
- **Characterisation golden: already answered as a real consequence** — coherent NA-tone shift, orderings
  preserved → authorized honest regen.

**Per-read-out question, applied to each affected assertion:** is the shift **(a) a real behavioural
consequence of correct NA** (accept; re-baseline honestly, mechanism documented) or **(b) a read-out that
conflates tone with signal** (fix the read-out, on principle, validated tone-invariant)? Answer it
per-read-out with evidence — never by which answer is convenient.

This is a class of latent measurement issue that a *correct* LC exposes. Register it; it will recur as other
dead hubs (BF-ACh, SNc) are completed.

## 7. Land
- Corrected read-out specified + justified + **tone-invariance validated** → then the CU answer read and
  documented (whatever it is).
- Acting-readiness diagnosed (a/b/c) and surfaced.
- LC 0.15 held; phasic CeA→LC; α2 non-plastic grounded, not load-bearing; B dropped+registered.
- Characterisation golden regen honestly (authorized).
- Full suite green **only once each failure is understood** — none regenerated to force a green.
- **Commit + push + STOP for reviewer clearance.**

## Process
No result is a target — **both ways**: don't pick the read-out that yields the CU signature, and don't erase
one that survives a validated read-out. Specify → validate → read. Grounded values are held; consequences are
findings. Dual-reviewed on the remote.
