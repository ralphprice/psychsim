# LC α2 Latch — CORRECTED RULING: make CeA→LC phasic (drop A+B) — Claude Code

**Outstanding work — you built A+B as I ruled, the load-bearing verification FALSIFIED it with clean data,
and you held rather than forcing my ruling or quietly falling back. My A+B ruling was WRONG, and your data
shows exactly why. You found the better mechanism. RULING CORRECTED: make CeA→LC phasic/adapting; drop A+B.**

## A+B is falsified (verified on the remote)
- **CeA→PAG and CeA→HYPdm are INHIBITORY** (CeA GABAergic). So candidate B (damping CeA) **disinhibits the
  attack effectors** → `test_aggression_pathway` flips restrain→aggress at B≥~0.5. The v9 keystone has thin
  headroom (0.193 vs ~0.23) — any tonic CeA damping eats it. **B breaks a committed keystone.**
- **B does NOT de-load-bear α2** — your sweep shows the loop needs α2 strong *regardless* of B (α2=0.5
  latches even at B=0.5). My premise ("B carries CeA-side stability → α2 no longer load-bearing") was
  **empirically false.**
- **No B does both** — the B that de-load-bears α2 (≥0.85) is well past the B that breaks aggression (~0.5).

**My error, named:** I proposed a *tonic* CeA self-brake to fix a latch caused by a *tonic* CeA→LC drive —
treating the symptom with another tonic mechanism, when the real problem is the drive is unphysiologically
tonic. You saw it; I didn't.

## The real fix (your recommendation — adopt it): make CeA→LC PHASIC
The latch and the original tonic-NA artifact have the **SAME root cause: a tonic CeA→LC drive.** And the fix
is the SAME insight that already resolved the teaching signal *in this arc*: **make the drive phasic.**
Confirmed on the remote: CeA→PAG/HYPdm inhibitory (so B breaks the keystone), and CeA→LC is currently
tonic-linear (transmits CeA's plateau level — the unphysiological part).

- **Physiological grounding:** CRF release from CeA is **phasic/adapting** — it fires on the event and adapts,
  it does NOT tonically clamp. The tonic CeA→LC edge is the unphysiological part.
- **The fix:** make CeA→LC a **phasic/adapting drive** — from CeA's **deviation above its running baseline**,
  using the `mean_activity` machinery **already built in this arc** for the teaching signal. At plateau the
  drive → 0.
- **Why it resolves all three at once:**
  - **Latch:** at plateau drive→0 → the loop **can't latch, regardless of α2.** Dissolved at the source
    (confirmed: adapting CeA→LC→0 lets CeA recover 1.000→0.433).
  - **α2 de-load-bears:** the loop is no longer sustained by a tonic drive, so α2 doesn't fight a tonic
    feedback → α2 returns to its **own grounded pharmacological value.**
  - **Aggression keystone preserved:** baseline/acute CeA is **untouched** (no CeA damping — the exact thing
    B broke). `test_aggression_pathway` stays restrain.

## The build
1. **CeA→LC → phasic/adapting** — drive from CeA's deviation above running baseline (existing `mean_activity`
   machinery), grounded in phasic CRF release. Baseline/acute CeA untouched.
2. **α2 (LC→LC) stays non-plastic** (category correction still right), but **drop it to its grounded
   pharmacological value** and **VERIFY the loop is stable at that grounded value** (the phasic drive, not α2,
   now prevents the latch). **This is the load-bearing check:** confirm α2 is no longer load-bearing —
   empirically, by dropping it to grounded and seeing the loop stays stable.
3. **Drop B** (CeA self-inhibition) — breaks the keystone, doesn't de-load-bear α2. **Register:** "CeA
   activity-driven self-inhibition is a real absent mechanism, but adding it TONICALLY disinhibits the attack
   effectors and breaks v9 — if ever added it must be phasic/non-keystone-breaking. Deferred."
4. **Register the general question:** "per-edge phasic character as a general option — other edges where the
   biology is phasic/adapting. Introduced specifically for CeA→LC (grounded in CRF phasic release) using
   existing machinery; revisit as a general property if more edges need it." (Do the grounded specific thing
   now; flag the general question.)

## Verify + land
- Latch dissolved (CeA recovers ≈ HEAD through neutral episodes) — **because the phasic drive→0 at plateau,
  not because α2 is strong.**
- **α2 at its grounded pharmacological value, loop still stable** → α2 confirmed NOT load-bearing (empirically,
  not asserted). This is the honesty gate.
- Aggression keystone preserved (`test_aggression_pathway` restrain — baseline CeA untouched).
- NA still fires phasically; `test_coactive_connection_strengthens` + `test_substrate_learning` green.
- Arena viable — **emergent from the physiologically-phasic drive at grounded α2, nothing tuned.**
- Full suite green (golden regen HONESTLY); v9 + Phase-1 intact.
- **Commit + push + STOP for reviewer clearance.** Then — only then — the two CU-shift re-examinations on the
  fully-clean mechanism.

## Why this is the honest answer (the "no result is a target" resolution, now clean)
Candidate A greened but α2 was load-bearing (suspect — you didn't accept it). A+B broke the keystone (you
didn't force my ruling). **Phasic CeA→LC removes the CAUSE** (the tonic drive), so viability emerges from the
physiologically-correct phasic mechanism with α2 at its grounded value — nothing tuned, nothing masked, the
keystone preserved. NOW the viable arena is trustworthy. Same phasic insight that fixed the teaching signal
this arc, applied to the drive. Your holding — accepting neither A nor A+B, tracing to the real mechanism —
was exactly right.

## Process
Current architecture only; the phasic drive uses existing `mean_activity` machinery (not new architecture) +
one grounded citation (CRF phasic release); **α2 value must be pharmacological and verified-not-load-bearing,
NOT loop-stabilizing**; register the two deferred items; no result is a target (both ways); dual-reviewed on
the remote.
