# Phase A — column rulings
**Supersedes the phasing note only. `PsychSim_Expression_Build_Handover.md` Phase A ≡ the earlier ruling's
Phase 0 — same work. These three answers complete its design. Build straight through after reading.**

Your `PAG-PANIC` find is the important one: it **already self-describes as "separation-distress &
vocalisation system (distinct column from the threat PAG)."** The model already has the third column, and it
is already named a vocalisation system. **So the split is `PAG → vlPAG + dPAG` only. `PAG-PANIC` stays as it
is** — it was never part of the lumping.

---

## Q1 — the ungrounded three: (c). Researched. All three resolve; none needs a flagged guess.

**First, why (b) was never available, because this is the general rule:** **structure is the one thing this
model claims is grounded.** §0/§8: *grounded — structure (which circuits, which connections); scaffold —
weights.* **A guessed column is a guessed structure**, and it determines what the circuit *does* — it is not
a band that later calibration can fix. Weights may be scaffold. **Structure may not.** Your refusal to pick
an uncited column was exactly right, and the answer to an ungrounded structural call is always: go and get
the grounding.

### SC-Pv → **dPAG**. Grounded.
Excitatory input from the superior colliculus **mostly targets the dorsal PAG**; dlPAG activation induces
flight, l/vlPAG induces freezing (Bandler & Shipley 1994; Tovote et al. 2016). vlPAG does **not** participate
in *unconditioned* defensive behaviour — which is what a looming innate reinforcer is. Route it to `dPAG`.

**And a finding you must surface, not fold in.** The mechanism is specific: threat reaches dPAG from the deep
medial SC **via weak, unreliable synapses, so that only very salient and imminent threats generate enough
synaptic activity to fire dPAG neurons.** **The threat-imminence threshold lives in the synapse's weakness.**
The model has `SC-Pv → PAG` at **0.50 (moderate)** — the literature says this synapse is characteristically
**weak, and that the weakness *is* the mechanism.** That is a **grounded qualitative weight statement**
(Point-1 class: a research-grounded innate strength), not a tune. **Do not change it inside this split.
Report it as a Point-1 candidate for its own reviewed pass** — it is an innate-reinforcer link, and changing
it will move the looming response.

### BNST → **vlPAG**. Grounded — and it is another target-cell case.
BSTdm → **ventrolateral PAG** by retrograde tracing (Gray & Magnuson 1992); vlPAG sits in the central
autonomic control network alongside CeA and the BST anterolateral group. Fits the function: BNST is the
sustained-threat node; vlPAG is passive coping. **But note: the BNST → anterior-vlPAG projection is
GABAergic** (Hao et al. 2019, *Cell Rep*) — **so this is the same shape as `CeA → vlPAG`.** Ground the target
cell before signing it; if it targets the vlPAG GABAergic population, it routes through `vlPAG-GABA` like
CeA does. **Bring it with the CeA one; do not sign it by the transmitter fallback.**

### DRN → **both columns**. Not a hedge — the documented character.
A diffuse raphe modulator projecting to both columns **is** the anatomy; each column has a distinctive set of
*ascending and descending* afferents, but a neuromodulator hub is not in that logic — it broadcasts (as DRN
already does across this substrate). **Route to both, and carry the existing 5-HT1A/2A receptor flag onto
both.** It then holds two disclosed ambiguities — receptor and column. **Both honest, both registered for the
209-edge audit. A disclosed ambiguity is a documented limitation; only a hidden guess is a fudge.**

*(Your other three stand: `CeA → vlPAG` via the Tovote interneuron; `VMHvl → dPAG` — its own source names the
column; `VMH → vlPAG` by its cited function. Route by the cited function, as you did.)*

---

## Q2 — weight conservation: **do not conserve. Do not split the number.** On the record, as asked.

**Conservation across a split is not a grounded principle — it is an invented conservation law, and obeying
it would preserve an artifact of the lumping.** The reasoning, in order:

1. **Nobody measured 0.50.** `basis: "anatomy"` means *the projection is real; the number is a placeholder
   band*. There is no measured quantity here to conserve.
2. **0.25/0.25 invents a ratio to preserve a number that was never real.** That is a fudge with a
   conservation law painted on it — worse than an honest band, because it looks principled.
3. **0.50/0.50 does not "double" anything real.** It represents two projections that were always there and
   were being carried as one. **The lumped edge was under-representing, not over-representing.**
4. **Rule 8 already answers this.** `normalise_incoming` holds each target's incoming drive at
   `max(1.0, len × 0.5)`. **`vlPAG` and `dPAG` each normalise their own afferent set independently.** The
   mechanism already conserves drive per circuit — **do not invent a second conservation law on top of the
   one the substrate has.**

**Ruling: each resolved edge takes the band its own anatomy supports, independently.** Where the literature
differentiates, use it — grounded (SC→dPAG is the one case, and it goes to its own pass per Q1). Where it
does not, **both inherit the parent's band, marked `# SCAFFOLD`.**

**Dynamics will move. That is expected and it is the point** — report what moves; do not rebalance; and per
the researcher's ruling, **do not tune**: values are scaffold pending the audit and the self-regulation
mechanism.

---

## Q3 — NuAmb: **(a) additive — rename + add. It is not the same case as PAG.**

**The distinction matters and is worth recording, because it will recur through the 209-edge audit:**

- **`PAG` is genuinely LUMPED** — its `function` names both columns, its `nodes` field says *"dorsal PAG /
  ventrolateral PAG"*, and its afferents are mixed across them. **Content genuinely mixed → SPLIT.**
- **`NuAmb` is correctly built but MIS-SCOPED** — its function, its citation (Saper & Stornetta 2015) and
  *both* its afferents (`PVN`, `NTS`) are **purely cardiac**. It is the loose/external formation wearing the
  whole nucleus's name. **There is nothing vocal inside it to divide.**

So: **re-mark the existing node `NuAmb-cardiac`** (a rename plus a function/source correction — nothing
moves, the cited cardiac edges stay intact) **and ADD `NuAmb-vocal`** (compact/semicompact formation;
laryngeal/pharyngeal; the common effector for voluntary *and* involuntary vocalisation) **as a new circuit.**

A symmetric split would assert the node was carrying both and we are dividing it — **false, and it would put
the cited cardiac edges at risk.** Additive is both honest and the substrate-only-grows rule.

> **The general rule: SPLIT a node when its content is genuinely mixed. RENAME-AND-ADD when it is correctly
> built but mis-scoped.** PAG is the first kind; NuAmb is the second.

---

## Build Phase A straight through
Splits (`PAG` → `vlPAG`/`dPAG`; `vlPAG-GABA` interneuron), `NuAmb` rename+add, `NuFac` added, the six
afferents routed as ruled above (with `CeA` and `BNST` target cells brought to review before signing), the
keystone re-expressed to what it protects (sign −1.0, weight 0.70, target explicit) — **then re-run the
neutral floor + phenomena battery and report what moves.** If the split flips a prior behavioural finding,
**that is a finding. Surface it; do not tune around it.**
