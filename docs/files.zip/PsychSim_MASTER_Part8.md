# PsychSim — Master Design & Build Document, Part 8 (Supplements & Addenda, continued)

*Sealed, versioned supplement to `PsychSim_MASTER.md` and Parts 1–7. Not updatable once distributed;
further guidance becomes a new Part. Section numbering continues the global sequence (this Part = S16).*

This Part answers "are we missing fundamental aggression circuits?" — **yes** — with a literature-
grounded account of what is missing, a v9 addition spec, the honesty constraint that governs it, and
the one sequencing decision it forces (relative to the Step-3 Panksepp cut).

---

## S16. The aggression circuit — deep-dive finding and v9 candidate

### S16.1 The diagnosis (why aggression can't win, precisely)

The Step-3 build found aggression competes as a live candidate but never wins, even under strong
threat, because the "attack effectors" it was mapped onto (`PAG`, `HYPdm`) are net-inhibited. The deep
dive shows *why*, and it's not a tuning problem: **the seed mapped aggression onto the *defence*
circuit, not the attack circuit.**
- v8 `PAG` is characterised *"Defensive output: freeze (vlPAG) / flight (dPAG)"* — the **defensive**
  PAG columns.
- v8 `HYPdm` is *"Autonomic/endocrine defensive drive"* — **defensive** hypothalamus.
- v8 `VMH` is *"Reproductive/sexual and social behaviour"* — the **reproductive** VMH.

Those are correctly inhibited for a fear-dominant (freeze/avoid) response. But **the attack-generating
circuit is a different subdivision** that v8 does not represent as such. So aggression can't win
because the circuit that generates it isn't in the connectome — only the defence circuit is.

### S16.2 The canonical attack circuit (grounded)

- **`VMHvl` (ventrolateral part of the ventromedial hypothalamus) → `lPAG` (lateral PAG)** is the core
  conspecific-attack generator and its motor output. Optogenetic stimulation of VMHvl evokes attack;
  silencing abolishes natural aggression (Lin et al. 2011, *Nature* 470:221). The VMHvl→lPAG projection
  is attack-*selective* and biting-locked; inactivating lPAG produces aggression-specific deficits
  (Falkner et al.; "hierarchical representations of aggression in a hypothalamic-midbrain circuit").
  This is anatomically distinct from the VMHdm→dPAG *predator-defence* pathway.
- **Upstream drive to VMHvl:** the medial amygdala (`MeA`) and posterior amygdala, `BNST`, the ventral
  premammillary nucleus (`PMv`), and the **ventral hippocampus** (stress-provoked aggression → VMH;
  post-weaning-isolation work). Olfactory/social identity arrives MeA → VMHvl.
- **Aggression as reward:** VMHvl activity drives operant responding for access to attack — aggression
  has an appetitive/seeking component (Falkner et al. 2016, *Nat. Neurosci.* 19:596).
- **Reactive aggression (the human model, Blair):** three ingredients — (1) **threat sensitivity**
  (amygdala; a lowered threshold via hostile attribution), (2) **frustrative non-reward** (deactivation
  of vmPFC/OFC and ventral striatum when expected reward is blocked, which *disinhibits* the acute
  threat system → arousal/vigilance), and (3) a **failure of prefrontal control** (vmPFC/OFC/dACC
  top-down regulation of the amygdala; reactive aggression = the regulation breaking down). The
  threat/attack core across the animal and human work is **amygdala + hypothalamus + PAG** (Blair 2016;
  reactive-aggression working model; frustration–aggression meta-analysis).

### S16.3 What v8 has vs misses

- **Has (but mischaracterised or defence-only):** `VMH` (reproductive), `PAG` (defensive), the
  `MeA → VMH → PAG` route (as reproductive/defensive), the amygdala nuclei, `BNST`, `LHb`
  (disappointment/negative RPE — the frustration *signal*), `HPCv`, and the PFC regulators.
- **Misses:**
  1. the **VMHvl attack subdivision** (as a functional node distinct from reproductive VMH);
  2. the **lPAG attack column** (distinct from the defensive vlPAG/dPAG);
  3. the **VMHvl → lPAG attack output** route;
  4. the **frustrative-non-reward → threat/attack disinhibition** pathway — the reactive-aggression
     *trigger* (the "thwarting pathway" the build flagged): blocked reward (via `LHb` / vmPFC-VS
     deactivation) disinhibiting the attack circuit;
  5. the **aggression-reward** link (VMHvl → appetitive value).

### S16.4 v9 addition spec (grounded; weights scaffold)

Preferred approach — **add distinct nodes** (cleaner than overloading the reproductive VMH / defensive
PAG):
- **Nodes:** `VMHvl` (conspecific-attack generator; domain `threat`/social; glutamatergic with the
  recurrent-excitation property noted), `lPAG` (attack motor output; distinct from defensive PAG),
  and `PMv` (ventral premammillary, upstream) if a cleaner upstream is wanted.
- **Connections (existence/direction grounded; weights `# SCAFFOLD`):** `MeA → VMHvl`,
  `PA/BNST → VMHvl`, `HPCv → VMHvl` (stress-provoked), `VMHvl → lPAG` (attack output), `VMHvl → NAc`
  (appetitive aggression / seeking); and the **reactive-aggression trigger** — a frustrative-non-reward
  route in which `LHb` (blocked-reward/disappointment) and reduced vmPFC/VS drive **disinhibit** the
  VMHvl/threat circuit — plus `vmPFC/OFC → VMHvl` **top-down regulation** (the control whose failure
  yields reactive aggression).
- **Sources:** Lin et al. 2011 (*Nature* 470:221); Falkner et al. 2014 (*J. Neurosci.* 34:5971), 2016
  (*Nat. Neurosci.* 19:596); Hashikawa et al. 2017; the VMHvl→lPAG hierarchical-circuit paper; Blair
  2016 and the reactive-aggression working model (Current Psychiatry Reports, 2020); the frustration–
  aggression neuroimaging meta-analysis.

### S16.5 The honesty constraint (governs the whole addition)

**The attack circuit is added to make the connectome grounded and complete — NOT to make aggression
win.** Weights are scaffold like everything else. **Whether aggression wins the behavioural race must
EMERGE** from the completed connectome — the balance of the attack circuit against its inhibition, plus
the triggers (threat, frustrative non-reward) and the top-down control. If, with the grounded circuit
and scaffold weights in place, aggression *still* does not win under provocation, that is a **finding**
(a calibration question, or a genuinely fear-dominant balance), **not** something to force by
hand-dis-inhibiting the attack effectors or weighting the pathway to win. Same rule as every other
emergence in the build: add the grounded mechanism, let the behaviour fall out, report what it does.

### S16.6 The sequencing decision (this is the choice to make)

Adding the attack circuit changes the parity picture for the Step-3 Panksepp cut, so the order matters:

- **v9-before-cut** (recommended): do the grounded aggression v9 pass *first*, then take the Step-3
  cut on a substrate whose aggression is properly represented — so Panksepp is retired against
  *complete* social-behaviour parity (reactive aggression included, emergent), not a known gap. Cleaner
  parity; couples a seed change with the cut, but both are reviewed.
- **cut-then-v9**: retire Panksepp now on current parity (aggression recorded as the OBS-3 gap), then
  add the aggression circuit as a subsequent grounded improvement to the sole substrate engine.
  Decouples the two, but leaves an interim where the sole engine cannot produce reactive aggression.

Recommendation: **v9-before-cut** — the attack circuit is real work the connectome needs regardless,
and doing it before the irreversible retirement means the cut lands on a substrate that can actually
produce the behaviour Panksepp produced. But it is a genuine strategic call (parity-completeness now
vs. decoupling the seed change from the cut), and it is the researcher's to make.

### S16.7 Batch with the other parked v9 candidate

If a v9 pass is run, fold in the other parked item so the seed is versioned once: the **S1.4 social
innate-wiring entries** (separation / contact / rejection) the functional layer carries but the
`innate_wiring_catalogue` lacks. Both are grounded, scaffold-weighted additions; a single v9 pass on
its own review folds in the aggression circuit (S16.4) and the social innate-wiring entries together.
Recall DA/satiety and continuous maturation both turned out *not* to need seed edits — so v9's scope is
exactly these two, nothing more.
