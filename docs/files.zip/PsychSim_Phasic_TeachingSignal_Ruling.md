# Phasic Teaching-Signal Fix — RULING (build as its own reviewed step) — Claude Code

**Approach approved — it's clean and reuses the substrate's OWN phasic machinery (the `_phasic_drive`/
`mean_activity` logic the teaching signal just wasn't using). Build it as its own reviewed step. Both
decisions ruled below. The LC foundation stays held (uncommitted) until this lands and clears.**

Reviewer-verified on the remote: the engine already tracks `mean_activity` as a running average
(`0.99*mean + 0.01*new`, engine.py:167), beside the BCM `theta`; the substrate already measures behaviour
phasically ("tonic cancels"). The fix applies that established phasic principle to the teaching signal.
Prototype confirmed: NA rest 0.220→0.000 (artifact gone), NA aversive 0.558→0.287 (still fires), DA reward
0.382→0.331 (preserved).

## Decision 1 — baseline reference: use the engine's running `mean_activity`. RULED.
Not the fixed `resting_baseline` capture. `mean_activity` is already tracked (no new plumbing), adaptive, and
matches the BCM-θ machinery it sits beside. **Crucially it is more *correct*, not just convenient:** because
it adapts, a genuinely *sustained* signal correctly decays to zero teaching signal — which is how phasic
neuromodulator teaching signals actually behave (they habituate to sustained stimuli; the teaching signal is
about *change*, not persistent state). A fixed baseline would wrongly keep signalling a sustained state.
Use `mean_activity`.

## Decision 2 — scope: R5 consolidation gate ONLY. RULED (+ flag the accessor question).
Make the **R5 teaching-signal gate** phasic — that is where the signal does its job (gating plasticity) and
where the tonic-NA artifact was causing over-consolidation. Fixing the gate fixes the artifact, minimally,
leaving behaviour-selection DA-gain and read-outs untouched.

**Do NOT also make `reward_signal()` (the accessor) phasic in this step.** The consistency argument
(`reward_signal()` is described as "the RPE," which is phasic) is real but not load-bearing: making the
accessor phasic would change whatever else reads it, for a tidiness we have no confirmed need for — and the
discipline is fix-what's-broken (the gate), don't-change-what-isn't (the accessor) for consistency alone.

**But flag it, don't drop it:** record in the gaps/consistency register the question — *is `reward_signal()`'s
absolute value a latent inconsistency (an "RPE" that isn't phasic) that should be made phasic for
correctness, deferred until something reading it needs phasic or until a teaching-signal-consistency pass?*
Deferred, not resolved now. (Same handling as other present-but-not-yet-biting items.)

## Build it as its own reviewed step — with the load-bearing regression check
- Implement: `teaching(nmod) = max(0, mean(source activations) − mean(source running baselines))` using
  `mean_activity`, at the R5 consolidation gate. General — resolves the deferred VTA-DA tonic/phasic case in
  the same stroke. **No `CeA→LC` tune.**
- **LOAD-BEARING regression:** `test_substrate_learning` must still PASS on phasic DA (the prototype shows DA
  preserved at 0.331, but the TEST is the gate — confirm direct reward-learning is genuinely intact, not just
  the number). This is the check that the general fix didn't break existing DA-gated learning.
- Verify: the tonic-NA artifact is gone (NA rest → ~0), NA still fires on aversive events (phasic), DA
  learning intact (`test_substrate_learning` green), full suite green (golden regen honestly if behaviour
  shifts — understood, not tuned).
- **Commit + push + STOP for reviewer clearance.** This lands as its own step BEFORE the LC foundation
  re-runs on top of it.

## Then (after this clears) — the payoff, set up honestly
1. **Re-run the LC foundation on the clean phasic signal** — `CeA→LC` via CRF-R1 now producing a *phasic* NA
   teaching signal (fires on aversive events, ~0 at rest).
2. **Re-examine the two confounded shifts** with the artifact removed:
   - CU punishment-deficit **persists** with phasic NA (genuinely starved by affective-empathy throttle, not
     tonic distortion) → **the REAL signature, un-confounded — a major finding** → re-characterize the
     punishment test honestly.
   - **Dissolves** → it was the tonic artifact; original "weak, not a failure" characterization stands.
   - Same for the `warm_firm`→defensive classification flip.
   Either way = a trustworthy answer, which is why we cleaned the mechanism first.

## Process
Current architecture only; integrate don't bolt on (reuse `mean_activity`/phasic machinery); no result is a
target (both directions); dual-reviewed on the remote; commit + push + STOP for clearance before the LC
re-run.
