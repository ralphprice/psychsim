# LC Afferent Completion — Ruling on Findings A & B — Claude Code

**Both findings verified on the remote and both are correct — good catches before committing. RULINGS below.
Net change: ONE cited edge (`CeA→LC` via `CRF-R1`) + ONE cited receptor-sign-map entry (`CRF-R1 → +1`) +
ONE gaps-register note. Minimal and functional — no inert edges added.**

## Finding A — RULING: `CeA→LC` via cited `CRF-R1` (add `CRF-R1 → +1` to `RECEPTOR_SIGN`). YES.

Confirmed: CeA is GABAergic (`GABAergic output neurons`; all efferents inhibitory). So a "plain excitatory
`CeA→LC`" is incoherent — it would come out inhibitory (threat *lowering* NA, backwards). This is the same
class as the `vlPFC→LA` fix: you don't assert the sign you want, you route through the mechanism that
produces it.

The honest mechanism is exactly what the Van Bockstaele citation names: the **CeA-CRF → LC** projection (the
CRF-containing amygdala afferents to LC), acting on **CRF-R1, which is Gs-coupled → excitatory**. This is
*why* threat drives noradrenergic arousal despite CeA being GABAergic — the CRF co-transmitter pathway, a
real distinct signaling route.

- **This is NOT sign gymnastics / a false-receptor flip** — it is citing the REAL receptor the grounding
  names. CRF-R1 being Gs-coupled/excitatory is textbook pharmacology (grounded, not chosen).
- **Add `CRF-R1 → +1` to `RECEPTOR_SIGN`** (grounded: CRF-R1 is Gs-coupled excitatory — standard CRF-R1
  pharmacology), and give `CeA→LC` the receptor `CRF-R1`, cited to the CeA-CRF→LC projection (Van Bockstaele).
- Adding a receptor to the sign map is legitimate + cited when the honest mechanism requires a receptor not
  yet mapped. Record the pharmacology basis. (It also correctly means CeA's projections aren't uniformly
  GABA-inhibitory — the CRF pathway is a real distinct route; CeA-CRF→LC is a documented instance.)
- Verified effect: threat now drives NA UP (0.05→0.58 nociception, 0.56 CO₂) — correctly, through the real
  mechanism — and it gates the NA-gated control edges (`dmPFC→LA`, `vlPFC→ITC`). The load-bearing edge works.

## Finding B — RULING: `CeA→LC` ONLY. Defer `PBN→LC` / `NTS→LC` (do NOT add now).

Confirmed: PBN (fed by SOM-relay/NTS/aIns) and NTS (fed by IN-INTERO) have **no aversive/nociceptive
afferents** — they are flat under every aversive condition. So `PBN→LC`/`NTS→LC` would be grounded anatomy
but **inert by construction** — their *sources* have no aversive drive at all in the current model. That is a
step removed from honest present-but-latent anatomy; it is adding downstream wiring for an upstream drive
that doesn't exist.

- **Do NOT add them now.** Our discipline: don't add apparatus that isn't doing anything. Adding edges whose
  sources never fire under threat clutters the substrate with inert wiring and obscures what actually carries
  signal.
- **`CeA→LC` alone completes the NA teaching signal** — it is the one edge that fires. Keep the addition
  minimal and functional.
- **Record in the gaps register:** `PBN→LC` and `NTS→LC` are known grounded noradrenergic afferents, DEFERRED
  until their sources carry aversive drive (i.e. until the model gains spino-parabrachial nociceptive input,
  nociception→PBN, which it currently lacks). Add them WITH that drive when it exists — not ahead of it. (Same
  handling as other grounded-but-not-yet-live items flagged in the register.)

## The build (minimal, functional)
- Add `CRF-R1 → +1` to `RECEPTOR_SIGN` (cited: Gs-coupled excitatory pharmacology).
- Add edge `CeA→LC`, receptor `CRF-R1`, cited (Van Bockstaele CeA-CRF→LC), at band, excitatory-via-CRF-R1.
- Register-note the deferred `PBN→LC`/`NTS→LC` (grounded, dormant-until-source-drive-exists).
- **No other change** — no other edge (weight/sign/basis), plasticity/engine byte-identical, net edges +1.

## Verify (foundation step — landed on its own, like PVN-OT)
- **NA teaching signal FIRES:** aversive event (nociception/CeA/CO₂) → `CeA→LC` → `neuromod_output("NA")`
  rises (0.05→~0.58), the way reward drives DA. Report the aversive→NA gradient.
- **It reaches the control edges:** the risen NA gates `dmPFC→LA`/`vlPFC→ITC` consolidation (control edges
  now drivable by an aversive teaching signal — the NA analog of "OT drivable by touch").
- **`CRF-R1` sign-map entry cited** (Gs-coupled); `CeA→LC` cited; additive (+1 edge); plasticity/engine
  byte-identical; no other edge changed.
- **Full suite green** (golden regen honestly if behaviour shifts — an aversive NA signal now firing may
  shift behaviour; understood, not tuned); v9 + Phase-1 + consequence-learning intact.
- **Commit + push + STOP for reviewer clearance** — this is the reviewed foundation step. The vicarious
  mechanism (observed punishment → NA at reduced gain → control edges) is the SEPARATE next step, after this
  clears.

## Process
Current architecture only; integrate don't bolt on; grounded/cited per edge + the receptor entry;
dual-reviewed on the remote; no result is a target.
